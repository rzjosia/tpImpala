# tpimpala

executer:

```shell script
bash Tp1_partie2.sh
```
